'use strict';
const name = 'Max Mustermann';
console.log(name.indexOf('M'));     // Ausgabe: 0
console.log(name.indexOf('mann'));  // Ausgabe: 10