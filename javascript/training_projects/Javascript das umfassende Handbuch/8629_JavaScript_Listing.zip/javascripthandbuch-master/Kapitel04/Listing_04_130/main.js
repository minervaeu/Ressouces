'use strict';
const regExp = /[0-9][0-9] [0-9][0-9] [0-9][0-9][0-9][0-9][0-9][0-9][0-9]/;
console.log(regExp.test('49X30X1234567')); // false