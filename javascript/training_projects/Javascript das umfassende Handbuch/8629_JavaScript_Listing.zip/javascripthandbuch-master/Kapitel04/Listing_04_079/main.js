'use strict';
const bestOfStonerrock = [
  'Kyuss',
  'Spiritual Beggars',
  'Spice and the RJ Band',
  'Band of Spice'
];
let one;
let two;
let three;
let four;

[
  one,
  two,
  three,
  four
] = bestOfStonerrock;