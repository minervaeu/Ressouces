'use strict';
const bestOfStonerrock = [
  'Kyuss',
  'Spiritual Beggars',
  'Spice and the RJ Band',
  'Band of Spice'
];
const [
  one,
  , // Hier wird keine Variable angegeben.
  three,
  four
  ] = bestOfStonerrock;
console.log(one);     // "Kyuss"
// console.log(two);  // Fehler, da nicht definiert
console.log(three);   // "Spice and the RJ Band"
console.log(four);    // "Band of Spice"