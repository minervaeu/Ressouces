'use strict';
const name = 'Max Mustermann';
console.log(name.substring(4, 10)); // Muster
console.log(name.substring(4));     // Mustermann
console.log(name.substr(4, 6));     // Muster
console.log(name.substr(4));        // Mustermann