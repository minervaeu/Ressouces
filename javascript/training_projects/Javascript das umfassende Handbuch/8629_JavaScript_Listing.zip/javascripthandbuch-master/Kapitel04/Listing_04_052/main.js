'use strict';
const contacts = [
  {
    firstName: 'Max',
    lastName: 'Mustermann',
    email: 'max.mustermann@javascripthandbuch.de'
  },
  {
    firstName: 'Moritz',
    lastName: 'Mustermann',
    email: 'moritz.mustermann@javascripthandbuch.de'
  },
  {
    firstName: 'Peter',
    lastName: 'Mustermann',
    email: 'peter.mustermann@javascripthandbuch.de'
  }
];