'use strict';
const person = {
  firstName : 'Max',
  lastName : 'Mustermann'
};
const {
  firstName : firstNameExtracted,
  lastName : lastNameExtracted
  } = person;