'use strict';
const regExp = /abcde/;