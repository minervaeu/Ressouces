'use strict';
const name = 'Max Mustermann';
console.log(name.slice(0, 4));  // Ausgabe: "Max "
console.log(name.slice(4));     // Ausgabe: "Mustermann"
console.log(name.slice(4, 10)); // Ausgabe: "Muster"