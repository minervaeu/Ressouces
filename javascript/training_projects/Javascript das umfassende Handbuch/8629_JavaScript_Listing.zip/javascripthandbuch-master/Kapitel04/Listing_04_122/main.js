'use strict';
const regExp = new RegExp('abcde');