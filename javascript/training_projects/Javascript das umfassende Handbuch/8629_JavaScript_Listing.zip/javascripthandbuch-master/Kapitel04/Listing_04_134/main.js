'use strict';
const regExp = /n$/;
console.log(regExp.test('Streuselkuchen'));         // true
console.log(regExp.test('Streuselkuchengeschäft')); // false