'use strict';
const bestOfStonerrock = [
  'Kyuss',
  'Spiritual Beggars',
  'Spice and the RJ Band',
  'Band of Spice'
];

const [
  one,
  two,
  three,
  four,
  five
  ] = bestOfStonerrock;

console.log(one);   // "Kyuss"
console.log(two);   // "Spiritual Beggars"
console.log(three); // "Spice and the RJ Band"
console.log(four);  // "Band of Spice"