'use strict';
const names = new Array();