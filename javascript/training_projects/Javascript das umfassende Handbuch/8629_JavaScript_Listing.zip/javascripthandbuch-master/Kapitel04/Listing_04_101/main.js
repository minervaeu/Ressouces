'use strict';
const name = 'Max Mustermann';
console.log(name.slice(-10, -4)); // Ausgabe: "Muster"