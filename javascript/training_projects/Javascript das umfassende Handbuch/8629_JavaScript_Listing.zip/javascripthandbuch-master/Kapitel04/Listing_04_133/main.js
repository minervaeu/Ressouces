'use strict';
const regExp = /^S/;
console.log(regExp.test('Streuselkuchen'));     // true
console.log(regExp.test('Der Streuselkuchen')); // false