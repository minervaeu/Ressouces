'use strict';
const regExp = /abcde/;
console.log(regExp.test('abcdefghijklmnopqrstuvwxyz')); // Ausgabe: true