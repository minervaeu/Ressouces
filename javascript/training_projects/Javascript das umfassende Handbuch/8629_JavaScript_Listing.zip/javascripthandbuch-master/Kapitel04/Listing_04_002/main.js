'use strict';
function example(x) {
  console.log(x);
  x = 5;
  console.log(x);
}
let y = 4711;
console.log(y);
example(y);
console.log(y);