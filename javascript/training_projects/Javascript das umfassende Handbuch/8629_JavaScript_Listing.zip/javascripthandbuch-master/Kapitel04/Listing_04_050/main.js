'use strict';
const names = new Array('Max', 'Moritz', 'Peter');
console.log(names.length); // Ausgabe: 3