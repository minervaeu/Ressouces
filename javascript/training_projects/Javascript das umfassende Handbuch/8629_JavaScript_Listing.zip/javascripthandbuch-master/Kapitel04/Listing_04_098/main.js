'use strict';
const name = 'Max Mustermann';
console.log(name.indexOf('M', 2)); // Ausgabe: 4