'use strict';
const names = ['Max', 'Moritz', 'Peter'];
names.reverse();
console.log(names); // Ausgabe: Peter, Moritz, Max