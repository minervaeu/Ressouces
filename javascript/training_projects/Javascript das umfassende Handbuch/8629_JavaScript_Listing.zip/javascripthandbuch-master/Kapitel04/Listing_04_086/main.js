'use strict';
const person = {
  firstName : 'Max',
  lastName : 'Mustermann'
};
const {
  firstName,
  lastName
  } = person;