'use strict';
const name = 'Max Mustermann';
console.log(name.lastIndexOf('M'));     // Ausgabe: 4
console.log(name.lastIndexOf('M', 2));  // Ausgabe: 0