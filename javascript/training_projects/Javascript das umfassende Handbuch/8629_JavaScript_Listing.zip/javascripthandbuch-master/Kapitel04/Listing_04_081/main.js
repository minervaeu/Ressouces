'use strict';
const bestOfStonerrock = [
  'Spiritual Beggars',
  'Spice and the RJ Band'
];
const [
  one = 'Kyuss',
  two = 'Kyuss',
  three = 'Kyuss',
  four = 'Kyuss'
  ] = bestOfStonerrock;
console.log(one); // "Kyuss";
console.log(two); // "Kyuss";
console.log(three); // "Kyuss";
console.log(four); // "Kyuss";