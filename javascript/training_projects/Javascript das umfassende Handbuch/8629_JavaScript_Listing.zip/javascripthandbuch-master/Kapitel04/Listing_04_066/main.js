'use strict';
const values = [7, 6, 4, 8, 7, 2, 4];
values.sort(compare);
console.log(values); // 2, 4, 4, 6, 7, 7