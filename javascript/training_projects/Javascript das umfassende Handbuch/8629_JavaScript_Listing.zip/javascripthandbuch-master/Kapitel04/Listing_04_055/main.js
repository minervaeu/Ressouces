'use strict';
const todoList = [
  'Bad putzen',           // Element an Index 0
  'Einkaufen',            // Element an Index 1
  'Aufräumen',            // Element an Index 2
  'Rasen mähen'           // Element an Index 3
];
for (let i = 0; i < todoList.length; i++) {
  console.log(todoList[i]);
}