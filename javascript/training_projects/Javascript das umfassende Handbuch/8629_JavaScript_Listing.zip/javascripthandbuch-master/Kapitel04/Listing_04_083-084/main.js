'use strict';
const coordinates = [
  [2,3,4],
  [5,6,7],
  [8,9,10]
];
const [
  [x1,y1,z1],
  [x2,y2,z2],
  [x3,y3,z3]
  ] = coordinates;