'use strict';
const bestOfStonerrock = [
  'Kyuss',
  'Spiritual Beggars',
  'Spice and the RJ Band',
  'Band of Spice'
];
const one = bestOfStonerrock[0];
const two = bestOfStonerrock[1];
const three = bestOfStonerrock[2];
const four = bestOfStonerrock[3];