'use strict';
const max = {
    firstName: 'Max',
    lastName: 'Mustermann'
}
const numbers = [2, 3, 4, 5, 6, 7, 8, 9];
console.log(Array.isArray(max));     // false
console.log(Array.isArray(numbers)); // true