'use strict';
const names = new Array(20);