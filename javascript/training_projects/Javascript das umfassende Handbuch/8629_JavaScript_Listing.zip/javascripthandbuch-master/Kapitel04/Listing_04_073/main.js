'use strict';
const result = [2,3,4,5,6,7,2,3,4,5]
  .find(element => element % 2 !== 0)
console.log(result); // 3

const result2 = [2,3,4,5,6,7,2,3,4,5]
  findIndex(element => element % 2 !== 0);
console.log(result2); // 1