'use strict';
const todoList = [
  'Bad putzen',           // Element an Index 0
  'Einkaufen',            // Element an Index 1
  'Aufräumen',            // Element an Index 2
  'Rasen mähen'           // Element an Index 3
];
console.log(todoList[0]); // "Bad putzen"
console.log(todoList[1]); // "Einkaufen"
console.log(todoList[2]); // "Aufräumen"
console.log(todoList[3]); // "Rasen mähen"
console.log(todoList[4]); // undefined