'use strict';
const names = new Array('Max', 'Moritz', 'Peter');