'use strict';
console.log(true instanceof Object);              // false
console.log(4711 instanceof Object);              // false
console.log('Max Mustermann' instanceof Object);  // false