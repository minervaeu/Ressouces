'use strict';
const names = ['Max', 'Moritz', 'Peter']; // Erzeugen eines Arrays mit bestimmten
                                        // Werten
const colors = [];                        // Erzeugen eines leeren Arrays