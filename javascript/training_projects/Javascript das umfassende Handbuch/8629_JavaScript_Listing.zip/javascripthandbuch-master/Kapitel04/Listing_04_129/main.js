'use strict';
console.log(regExp.test('49X30X1234567')); // true