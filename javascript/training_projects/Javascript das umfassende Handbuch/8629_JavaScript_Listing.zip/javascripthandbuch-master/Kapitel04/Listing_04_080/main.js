'use strict';
const bestOfStonerrock = [
  'Kyuss',
  'Spiritual Beggars',
  'Spice and the RJ Band',
  'Band of Spice'
];
const [
  one,
  two,
  three,
  four,
  five
  ] = bestOfStonerrock;
console.log(five); // undefined