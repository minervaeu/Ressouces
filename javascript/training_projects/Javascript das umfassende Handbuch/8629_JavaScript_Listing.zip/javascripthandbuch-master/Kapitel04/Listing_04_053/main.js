'use strict';
const values = [];
values[0] = 'Max';
values[1] = 4711;
values[2] = true;