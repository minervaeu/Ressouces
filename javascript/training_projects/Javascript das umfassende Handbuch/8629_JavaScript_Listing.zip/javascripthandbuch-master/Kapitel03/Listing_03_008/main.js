'use strict';
// const 2ndName = 'Moritz'; // ungültig, da mit Zahl beginnend
// const first%Name = 'Max'; // ungültig, da Sonderzeichen enthaltend
// const first-name = 'Max'; // ungültig, da Bindestrich enthaltend
const first_name = 'Max'; // gültig
const _firstName = 'Max'; // gültig
const $firstName = 'Max'; // gültig