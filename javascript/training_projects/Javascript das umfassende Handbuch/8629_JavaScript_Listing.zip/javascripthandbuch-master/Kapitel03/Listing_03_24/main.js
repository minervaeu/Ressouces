'use strict';
const message = `Hallo Welt.`;
console.log(message); // Hallo Welt.