'use strict';
const message = 'Sehr geehrter Herr Mustermann, \n\ngerne übersenden wir ' +
  'Ihnen die geforderten Unterlagen zur Prüfung zurück. \n\n' +
  'Mit freundlichen Grüßen, \nFrau Musterfrau, \nMusterfirma';
console.log(message);
// Ausgabe:
//
// Sehr geehrter Herr Mustermann,
//
// gerne übersenden wir Ihnen die geforderten Unterlagen zur Prüfung zurück.
//
// Mit freundlichen Grüßen,
// Frau Musterfrau,
// Musterfirma