'use strict';
do {
// Anweisung(en)
} while (Ausdruck)