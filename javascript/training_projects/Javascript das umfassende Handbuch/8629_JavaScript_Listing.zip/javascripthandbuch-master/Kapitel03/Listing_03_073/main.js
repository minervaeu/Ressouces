'use strict';
const variable = condition ? value1 : value2;