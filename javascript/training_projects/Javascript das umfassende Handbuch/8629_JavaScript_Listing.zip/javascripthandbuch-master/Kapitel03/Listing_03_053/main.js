'use strict';
console.log(false === 0); // Ausgabe: false
console.log(false === 1); // Ausgabe: false
console.log(true === 1); // Ausgabe: false
console.log(true === 0); // Ausgabe: false
console.log("4711" === 4711); // Ausgabe: false
console.log(false !== 0); // Ausgabe: true
console.log(false !== 1); // Ausgabe: true
console.log(true !== 1); // Ausgabe: true
console.log(true !== 0); // Ausgabe: true
console.log("4711" !== 4711); // Ausgabe: true