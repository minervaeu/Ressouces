'use strict';
switch(expression) {
  case value1:
// Anweisungen
    break;
  case value2:
// Anweisungen
    break;
  case value3:
// Anweisungen
    break;
  case value4:
// Anweisungen
    break;
  default:
// Anweisungen
}