'use strict';
for (
  Initialisierung; // wird vor Ausführen der Schleife ausgeführt
  Bedingung; // wird vor Ausführen einer Iteration überprüft
  Inkrementierungsausdruck // wird am Ende einer Iteration ausgeführt
) {
  Schleifenkörper // wird in jeder Iteration einmal ausgeführt
}