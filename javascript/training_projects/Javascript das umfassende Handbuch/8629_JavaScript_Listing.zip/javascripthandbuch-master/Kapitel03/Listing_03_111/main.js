'use strict';
showMessage(); // Aufruf möglich
function showMessage() {
  console.log('Herzlich willkommen');
}