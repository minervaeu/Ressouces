'use strict';
console.log(shoppingCart[0][0]); // Ausgabe: Plattenspieler
console.log(shoppingCart[0][1]); // Ausgabe: 200
console.log(shoppingCart[0][2]); // Ausgabe: 1
console.log(shoppingCart[1][0]); // Ausgabe: Lautsprecher
console.log(shoppingCart[1][1]); // Ausgabe: 400
console.log(shoppingCart[1][2]); // Ausgabe: 2
console.log(shoppingCart[2][0]); // Ausgabe: Vorverstärker
console.log(shoppingCart[2][1]); // Ausgabe: 80
console.log(shoppingCart[2][2]); // Ausgabe: 1
console.log(shoppingCart[3][0]); // Ausgabe: Lautsprecherkabel
console.log(shoppingCart[3][1]); // Ausgabe: 20
console.log(shoppingCart[3][2]); // Ausgabe: 2