'use strict';
const number = 22;    // Variable definieren
console.log(number);  // Ausgabe: 22
const console = 4711; // Variable definieren
console.log(number);  // TypeError: console.log is not a function