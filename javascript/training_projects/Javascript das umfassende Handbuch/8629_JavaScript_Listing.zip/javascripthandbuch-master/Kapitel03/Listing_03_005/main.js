'use strict';
let firstName = 'Max';
let lastName = 'Mustermann';