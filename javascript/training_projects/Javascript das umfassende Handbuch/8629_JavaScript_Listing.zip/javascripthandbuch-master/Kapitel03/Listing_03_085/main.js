'use strict';
// äußere Schleife
for (let i = 1; i < 11; i++) {
  // innere Schleife
  for (let j = 1; j < 11; j++) {
    console.log(`i hat den Wert "${i}", j hat den Wert "${j}"`);
  }
}