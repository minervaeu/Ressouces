'use strict';
const shoppingCart = [ // Beginn des äußeren Arrays
  [ // erster Eintrag
    'Plattenspieler', // erstes Element im ersten Array
    200, // zweites Element im ersten Array
    1 // drittes Element im ersten Array
  ],
  [ // zweiter Eintrag
    'Lautsprecher', // erstes Element im zweiten Array
    400, // zweites Element im zweiten Array
    2 // drittes Element im zweiten Array
  ],
  [ // dritter Eintrag
    'Vorverstärker', // erstes Element im dritten Array
    80, // zweites Element im dritten Array
    1 // drittes Element im dritten Array
  ],
  [ // vierter Eintrag
    'Lautsprecherkabel', // erstes Element im vierten Array
    20, // zweites Element im vierten Array
    2 // drittes Element im vierten Array
  ]
]; // Ende des äußeren Arrays