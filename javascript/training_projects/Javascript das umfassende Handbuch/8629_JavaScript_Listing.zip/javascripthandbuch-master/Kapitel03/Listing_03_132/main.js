'use strict';
function sum(x, y) {
  const result = x + y; // Addition der zwei übergebenen Parameter
  return result;      // Rückgabe des Ergebnisses
}