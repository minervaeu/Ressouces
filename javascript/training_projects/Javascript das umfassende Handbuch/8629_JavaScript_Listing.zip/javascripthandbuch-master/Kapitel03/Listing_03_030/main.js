'use strict';
const shoppingCartItem1 = 'Plattenspieler'; // erster Eintrag
const shoppingCartItem2 = 'Lautsprecher'; // zweiter Eintrag
const shoppingCartItem3 = 'Vorverstärker'; // dritter Eintrag
const shoppingCartItem4 = 'Lautsprecherkabel'; // vierter Eintrag