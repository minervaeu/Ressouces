'use strict';
const item1 = shoppingCart[0]; // erster Eintrag
const item2 = shoppingCart[1]; // zweiter Eintrag
const item3 = shoppingCart[2]; // dritter Eintrag
const item4 = shoppingCart[3]; // vierter Eintrag
console.log(item1); // 'Plattenspieler'
console.log(item2); // 'Lautsprecher'
console.log(item3); // 'Vorverstärker'
console.log(item4); // 'Lautsprecherkabel'