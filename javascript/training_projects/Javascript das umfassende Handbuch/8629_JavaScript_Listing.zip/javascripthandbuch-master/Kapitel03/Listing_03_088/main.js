'use strict';
while (Ausdruck) {
// Anweisung(en)
}