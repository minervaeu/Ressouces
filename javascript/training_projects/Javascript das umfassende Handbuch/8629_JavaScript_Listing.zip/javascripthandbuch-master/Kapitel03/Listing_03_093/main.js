'use strict';
let i = 1; // Initialisierung
do {
  console.log(i); // Anweisung
  i++; // Inkrementierung
} while (i < 11) // Bedingung