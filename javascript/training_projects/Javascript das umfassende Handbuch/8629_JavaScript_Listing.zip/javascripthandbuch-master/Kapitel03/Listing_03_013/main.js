'use strict';
const MAXIMUM = 5000;
MAXIMUM = 4711;       // hier potenzieller Laufzeitfehler
console.log(MAXIMUM); // Ausgabe: 5000