'use strict';
function showMessage() {
  'use strict';
  const message = 'Herzlich willkommen';
  console.log(message);
}