'use strict';
const userIsLoggedIn = true;
const userIsAdmin = false;
if(userIsLoggedIn && userIsAdmin) {
  /* ... */
}