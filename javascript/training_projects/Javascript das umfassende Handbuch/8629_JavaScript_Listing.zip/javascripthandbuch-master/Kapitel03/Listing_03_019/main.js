'use strict';
const firstName = 'Max'; // einfache Anführungszeichen
const lastName = "Mustermann"; // doppelte Anführungszeichen
const age = "22"; // keine Zahl, sondern Zeichenkette
// const street = 'Musterstraße"; // Syntaxfehler: Mischform