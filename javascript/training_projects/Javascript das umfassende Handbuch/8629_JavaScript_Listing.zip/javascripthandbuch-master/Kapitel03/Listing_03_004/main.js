'use strict';
let firstName;
let lastName;
firstName = 'Max';
lastName = 'Mustermann';