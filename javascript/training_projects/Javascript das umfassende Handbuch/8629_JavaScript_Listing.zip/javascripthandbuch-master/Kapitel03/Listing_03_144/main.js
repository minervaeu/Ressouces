'use strict';
const printHelloWorld = () => console.log('Hallo Welt');