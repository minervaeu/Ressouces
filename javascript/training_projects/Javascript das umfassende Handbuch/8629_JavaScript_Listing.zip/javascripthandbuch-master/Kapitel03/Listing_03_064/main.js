'use strict';
if(condition1) {
  // Programmzweig, der ausgeführt wird, falls Bedingung 1 erfüllt ist
} else if(condition2) {
  // Programmzweig, der ausgeführt wird, falls Bedingung 2 erfüllt ist
} else {
  // Programmzweig, der ausgeführt wird, falls keine der vorherigen ...
  // ... Bedingungen erfüllt ist
}