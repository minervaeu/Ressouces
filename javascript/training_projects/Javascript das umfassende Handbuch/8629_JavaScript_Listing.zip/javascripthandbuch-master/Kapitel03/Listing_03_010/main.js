'use strict';
const defaultValue = 2345;
const firstName = 'Max';
const lastName = 'Mustermann';
const isAdmin = true;
const userIsNotLoggedIn = true;