'use strict';
function sum(x, y) {
  return x + y; // Addition und Rückgabe
}
const resultOne = sum(5, 5);
const resultTwo = sum(8, 8);
console.log(resultOne); // 10
console.log(resultTwo); // 16