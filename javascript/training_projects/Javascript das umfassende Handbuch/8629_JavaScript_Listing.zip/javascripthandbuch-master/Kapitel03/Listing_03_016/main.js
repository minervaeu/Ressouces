const number1 = 050;    // Definition einer Oktalzahl (Dezimalwert 40)
// const number2 = 078; // ungültige Oktalzahl (Wert 78)
const number3 = 011147; // Definition einer Oktalzahl (Dezimalwert 4711)

console.log(number1); // 40
console.log(number3); // 4711