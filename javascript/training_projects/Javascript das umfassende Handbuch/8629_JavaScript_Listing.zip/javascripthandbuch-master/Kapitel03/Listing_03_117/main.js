'use strict';
function showMessage(message) {
  console.log(message);
}
showMessage('Moritz: Hallo Max');
showMessage('Max: Hallo Moritz');