'use strict';
console.log(Number.MIN_VALUE); // Ausgabe: 5e-324
console.log(Number.MAX_VALUE); // Ausgabe: 1.7976931348623157e+308
console.log(Number.NEGATIVE_INFINITY); // Ausgabe: -Infinity
console.log(Number.POSITIVE_INFINITY); // Ausgabe: Infinity