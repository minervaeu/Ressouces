'use strict';
showMessage(); // Aufruf nicht möglich, diese Anweisung produziert einen Fehler.
const showMessage = function() {
  console.log('Herzlich willkommen');
}