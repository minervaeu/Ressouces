'use strict';
const name = 'Max Mustermann';
const age = 44;
const message = `Mein Name ist ${name}, ich bin ${age} Jahre alt.`;
console.log(message); // Mein Name ist Max Mustermann, ich bin 44 Jahre alt.