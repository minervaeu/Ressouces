'use strict';
// Wenig aussagekräftige Variablennamen
const fn = 'Max ';
const ln = 'Mustermann ';
// Aussagekräftige Variablennamen
const firstName = 'Max ';
const lastName = 'Mustermann ';