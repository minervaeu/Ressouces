'use strict';
const salutation = 'Ihr persönlicher Newsletter,'; // Zeichenkette 1
const name = 'Max Mustermann'; // Zeichenkette 2
const message = salutation + ' ' + name; // Konkatenation plus Leerzeichen