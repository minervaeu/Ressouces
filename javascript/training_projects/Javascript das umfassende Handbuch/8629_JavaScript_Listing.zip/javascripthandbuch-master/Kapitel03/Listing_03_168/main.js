'use strict';
try {
// Code ausführen, der potenziell Fehler produziert
} catch (error) {
// Behandeln des Fehlers
} finally {
// Alles, was hier steht, wird immer ausgeführt, unabhängig davon,
// ob ein Fehler aufgetreten ist oder nicht.
}