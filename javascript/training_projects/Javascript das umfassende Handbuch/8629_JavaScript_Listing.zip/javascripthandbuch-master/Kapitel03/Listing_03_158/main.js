'use strict';
try {
// Code ausführen, der potenziell Fehler produziert
} catch (error) {
// Behandeln des Fehlers
}