'use strict';
const condition;
if(condition) {
  // Programmcode, der ausgeführt werden soll, falls Bedingung erfüllt ist
} else {
  // Programmcode, der ausgeführt werden soll, falls Bedingung nicht erfüllt ist
}