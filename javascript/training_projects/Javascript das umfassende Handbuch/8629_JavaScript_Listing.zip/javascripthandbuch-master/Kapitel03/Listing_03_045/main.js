'use strict';
let message = 'Ihr persönlicher Newsletter,';
message += ' ';
message += name;