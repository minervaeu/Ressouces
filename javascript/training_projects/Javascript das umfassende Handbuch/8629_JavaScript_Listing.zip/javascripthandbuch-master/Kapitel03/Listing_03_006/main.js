'use strict';
let x = 4711;
console.log(x); // Ausgabe: 4711
x = 5;
console.log(x); // Ausgabe: 5