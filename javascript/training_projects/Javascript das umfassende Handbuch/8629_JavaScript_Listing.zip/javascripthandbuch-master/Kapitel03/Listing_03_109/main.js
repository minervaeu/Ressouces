'use strict';
const showMessage = function showMessageFunctionName() {
  console.log('Herzlich willkommen');
}
showMessage();
// showMessageFunctionName(); // Aufruf nicht möglich