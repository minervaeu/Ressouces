'use strict';
function showMessage(message) {
  console.log(message);
}