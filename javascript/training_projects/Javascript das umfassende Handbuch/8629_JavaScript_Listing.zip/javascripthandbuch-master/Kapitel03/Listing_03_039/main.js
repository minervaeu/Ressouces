'use strict';
let name;
console.log(name); // Ausgabe: undefined
name = 'Max Mustermann';
console.log(name); // Ausgabe: Max Mustermann