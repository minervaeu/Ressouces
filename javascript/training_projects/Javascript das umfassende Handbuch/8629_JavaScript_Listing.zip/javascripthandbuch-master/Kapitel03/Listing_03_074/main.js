'use strict';
const age = prompt('Geben Sie bitte Ihr Alter ein.');
const isAtLeast18 = age >= 18 ? true : false;
console.log(isAtLeast18);