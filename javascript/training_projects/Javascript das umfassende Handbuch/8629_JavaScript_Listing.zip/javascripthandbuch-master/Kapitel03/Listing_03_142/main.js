'use strict'
const sum = (x, y) => x + y;