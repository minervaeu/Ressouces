'use strict';
const isLoggedIn = true;
const isAdmin = false;