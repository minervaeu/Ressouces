'use strict';
const showMessage = message => console.log(message);