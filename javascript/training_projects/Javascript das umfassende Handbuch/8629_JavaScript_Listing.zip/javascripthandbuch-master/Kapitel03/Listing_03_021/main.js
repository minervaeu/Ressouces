'use strict';
const message = 'Hallo\nHerr\nMustermann';
console.log(message);
// Ausgabe:
// Hallo
// Herr
// Mustermann