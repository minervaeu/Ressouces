'use strict';
const shoppingCart = [ // Beginn der Array-Definition
  'Plattenspieler', // erster Eintrag
  'Lautsprecher', // zweiter Eintrag
  'Vorverstärker', // dritter Eintrag
  'Lautsprecherkabel' // vierter Eintrag
]; // Ende der Array-Definition