'use strict';
function showMessage() {
  console.log('Herzlich willkommen');
}
showMessage(); // Ausgabe: "Herzlich willkommen"
showMessage(); // Ausgabe: "Herzlich willkommen"