'use strict';
const shoppingCart = [
  'Plattenspieler',
  'Lautsprecher',
  'Vorverstärker',
  'Lautsprecherkabel'
];