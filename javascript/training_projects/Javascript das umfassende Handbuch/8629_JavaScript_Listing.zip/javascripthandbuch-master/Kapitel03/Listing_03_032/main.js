'use strict';
const shoppingCart = [
  'Plattenspieler', 'Lautsprecher', 'Vorverstärker', 'Lautsprecherkabel'];
const highscores = [74334, 24344, 54533, 32553, 67556];