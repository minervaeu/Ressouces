'use strict';
const message = `Sehr geehrter Herr Mustermann,
gerne übersenden wir Ihnen die geforderten Unterlagen zur Prüfung zurück.
Mit freundlichen Grüßen,
Frau Musterfrau,
Musterfirma`;
console.log(message);
// Ausgabe:
//
// Sehr geehrter Herr Mustermann,
//
// gerne übersenden wir Ihnen die geforderten Unterlagen zur Prüfung zurück.
//
// Mit freundlichen Grüßen,
// Frau Musterfrau,
// Musterfirma