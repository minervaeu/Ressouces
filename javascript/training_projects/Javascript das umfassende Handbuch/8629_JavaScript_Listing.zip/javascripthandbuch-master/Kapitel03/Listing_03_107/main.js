'use strict';
function showMessage() {
  console.log('Herzlich willkommen');
}