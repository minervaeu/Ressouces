'use strict';
const showMessage = function() {
  console.log('Herzlich willkommen');
}
showMessage();