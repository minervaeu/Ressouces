'use strict';
if(condition1) {
// Programmzweig 1
} else if(condition2) {
// Programmzweig 2
}