'use strict';
let i = 1; // Initialisierung
while (i < 11) { // Bedingung
  console.log(i); // Anweisung
  i++; // Inkrementierung
}