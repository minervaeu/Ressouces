'use strict';
function printPersonInformation(firstName, lastName, age) {
  console.log(`Vorname: ${firstName}`);
  console.log(`Nachname: ${lastName}`);
  console.log(`Alter: ${age}`);
}
printPersonInformation('Max', 'Mustermann', 44);
printPersonInformation('Moritz', 'Mustermann', 55);