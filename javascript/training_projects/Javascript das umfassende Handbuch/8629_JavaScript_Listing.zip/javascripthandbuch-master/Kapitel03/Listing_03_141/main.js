'use strict';
const sum = (x, y) => {return x + y;}
// ... ist das gleiche wie ...
const sum = function(x, y) {
  return x + y;
}