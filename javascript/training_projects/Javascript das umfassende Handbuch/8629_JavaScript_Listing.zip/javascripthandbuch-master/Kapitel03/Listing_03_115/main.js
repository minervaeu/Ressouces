'use strict';
function showMessage() {
  console.log('Hallo Welt');
}
showMessage(); // Ausgabe: "Hallo Welt"
showMessage(); // Ausgabe: "Hallo Welt"