function showMessage() {
  alert('Hallo Welt');
}
showMessage();