function showMessage() {
  console.log('Hallo Entwicklerwelt');   // Ausgabe einer normalen Meldung
  console.debug('Hallo Entwicklerwelt'); // Ausgabe einer Debug-Meldung
  console.error('Hallo Entwicklerwelt'); // Ausgabe einer Fehlermeldung
  console.info('Hallo Entwicklerwelt');  // Ausgabe einer Infomeldung
  console.warn('Hallo Entwicklerwelt');  // Ausgabe einer Warnung
}
