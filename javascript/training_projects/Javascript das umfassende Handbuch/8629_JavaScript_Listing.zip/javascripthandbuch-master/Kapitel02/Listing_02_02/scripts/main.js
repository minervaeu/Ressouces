'Bad putzen'
'Einkaufen'
'Aufräumen'
'Rasen mähen'