function showMessage() {
  console.log('Hallo Entwicklerwelt');
}