function showMessage() {
  alert('Hallo Welt');
}
document.addEventListener('DOMContentLoaded', showMessage);