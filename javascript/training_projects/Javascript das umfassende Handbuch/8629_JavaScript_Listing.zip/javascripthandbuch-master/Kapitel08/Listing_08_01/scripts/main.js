function init() {
  console.log(window.innerHeight);
  console.log(window.innerWidth);
  console.log(window.screenX);
  console.log(window.screenY);
}

document.addEventListener('DOMContentLoaded', init);
